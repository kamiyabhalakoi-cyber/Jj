import base64
import re
import threading
import time
from pathlib import Path
from html.parser import HTMLParser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.request import Request, urlopen

SOURCE = 'https://t.me/s/TheFreeConfigs'
CACHE = Path.home() / '.thefreeconfigs-sub.b64'
BACKUP_SOURCE = 'https://raw.githubusercontent.com/0xRadikal/Free-v2ray-Configs/main/top100.txt'
BACKUP_CACHE = Path.home() / '.freeconfigs-backup.b64'
LINK = re.compile(r'(?:vless|vmess|trojan|ss)://[^\s<>"\x27\u200b]+', re.I)

class Page(HTMLParser):
    def __init__(self):
        super().__init__()
        self.links = []
    def handle_data(self, text):
        self.links.extend(LINK.findall(text))
    def handle_starttag(self, tag, attrs):
        href = dict(attrs).get('href') if tag == 'a' else None
        if href and LINK.fullmatch(href):
            self.links.append(href)

def refresh(source, cache, telegram=False):
    while True:
        try:
            with urlopen(Request(source, headers={'User-Agent': 'Mozilla/5.0'}), timeout=25) as res:
                html = res.read(5_000_001)
            if len(html) > 5_000_000:
                raise ValueError('Page too large')
            text = html.decode('utf-8', errors='replace')
            if telegram:
                page = Page()
                page.feed(text)
                candidates = page.links
            else:
                candidates = [line.strip() for line in text.splitlines() if LINK.fullmatch(line.strip())]
            unique = {link.split('#', 1)[0]: link for link in candidates}
            links = list(unique.values())[-100:]
            if not links:
                raise ValueError('No config links found')
            tmp = cache.with_suffix('.tmp')
            tmp.write_bytes(base64.b64encode('\n'.join(links).encode()))
            tmp.replace(cache)
            print(f'Refreshed: {len(links)} configs', flush=True)
        except Exception as exc:
            print(f'Refresh failed: {exc}. Keeping previous cache.', flush=True)
        time.sleep(300)

class Subscription(BaseHTTPRequestHandler):
    def do_GET(self):
        cache = {'/sub': CACHE, '/backup': BACKUP_CACHE}.get(self.path)
        if cache is None:
            self.send_error(404)
            return
        try:
            body = cache.read_bytes()
        except FileNotFoundError:
            self.send_error(503, 'No configs yet; check Termux output')
            return
        self.send_response(200)
        self.send_header('Content-Type', 'text/plain; charset=utf-8')
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(body)

if __name__ == '__main__':
    with ThreadingHTTPServer(('127.0.0.1', 8765), Subscription) as server:
        print('Subscription: http://127.0.0.1:8765/sub', flush=True)
        print('Backup: http://127.0.0.1:8765/backup', flush=True)
        threading.Thread(target=refresh, args=(SOURCE, CACHE, True), daemon=True).start()
        threading.Thread(target=refresh, args=(BACKUP_SOURCE, BACKUP_CACHE), daemon=True).start()
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            pass
